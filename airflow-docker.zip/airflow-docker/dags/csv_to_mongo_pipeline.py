from airflow import DAG
from airflow.operators.python import PythonOperator
from datetime import datetime, timedelta
import requests
import pymongo
import pandas as pd

# Configuração do MongoDB
MONGO_URI = "mongodb://mongo:27017/"
DATABASE_NAME = "airflow_db"
COLLECTION_NAME = "data_collection"

# Função para extrair os dados de uma API
def fetch_data_from_api():
    url = "https://jsonplaceholder.typicode.com/posts"  # Substitua pela URL da API desejada
    response = requests.get(url)
    data = response.json()
    df = pd.DataFrame(data)
    df.to_csv('/tmp/data.csv', index=False)
    print("Dados extraídos e salvos em /tmp/data.csv")

# Função para processar os dados
def process_data():
    df = pd.read_csv('/tmp/data.csv')
    df['title'] = df['title'].str.upper()
    df.to_csv('/tmp/processed_data.csv', index=False)
    print("Dados transformados e salvos em /tmp/processed_data.csv")

# Função para carregar os dados no MongoDB
def load_data_to_mongo():
    client = pymongo.MongoClient(MONGO_URI)
    db = client[DATABASE_NAME]
    collection = db[COLLECTION_NAME]

    df = pd.read_csv('/tmp/processed_data.csv')
    collection.insert_many(df.to_dict('records'))
    print(f"Dados carregados no MongoDB na coleção {COLLECTION_NAME}")

# Configuração do DAG
default_args = {
    'owner': 'airflow',
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
}
dag = DAG(
    dag_id='csv_to_mongo_pipeline',
    default_args=default_args,
    description='Pipeline para processar dados CSV de uma API e carregar no MongoDB',
    start_date=datetime(2024, 11, 1),
    schedule='@daily',
    catchup=False,
)


# Tarefas
fetch_task = PythonOperator(
    task_id='fetch_data',
    python_callable=fetch_data_from_api,
    dag=dag,
)

process_task = PythonOperator(
    task_id='process_data',
    python_callable=process_data,
    dag=dag,
)

load_task = PythonOperator(
    task_id='load_to_mongo',
    python_callable=load_data_to_mongo,
    dag=dag,
)

# Definindo a sequência das tarefas
fetch_task >> process_task >> load_task


